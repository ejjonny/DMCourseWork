//
//  EMMovie.h
//  MovieDBObjC
//
//  Created by Ethan John on 2/15/19.
//  Copyright © 2019 ya boy E. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface EMMovie : NSObject

@property (nonatomic, copy) NSString * title;
@property (nonatomic) double rating;
@property (nonatomic, copy) NSString * overview;
@property (nonatomic, copy) NSString * imagePath;

- (instancetype) initWithTitle:(NSString *)title
						rating:(double)rating
					  overview:(NSString *)overview
					 imagePath:(NSString *)imagePath;


@end

@interface EMMovie (JSONConvertible)

+ (NSMutableArray<EMMovie *> *) arrayWithDict:(NSDictionary *)dict;

@end

NS_ASSUME_NONNULL_END
