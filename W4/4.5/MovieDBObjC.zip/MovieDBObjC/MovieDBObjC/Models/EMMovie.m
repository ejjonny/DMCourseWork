//
//  EMMovie.m
//  MovieDBObjC
//
//  Created by Ethan John on 2/15/19.
//  Copyright © 2019 ya boy E. All rights reserved.
//

#import "EMMovie.h"

@implementation EMMovie

- (instancetype)initWithTitle:(NSString *)title rating:(double)rating overview:(NSString *)overview imagePath:(NSString *)imagePath
{
	self = [super init];
	if (self) {
		_title = title;
		_rating = rating;
		_overview = overview;
		_imagePath = imagePath;
	}
	return self;
}

@end

@implementation EMMovie (JSONConvertible)

+(NSMutableArray<EMMovie *> *) arrayWithDict:(NSDictionary *)dict
{
	
	NSMutableArray * movies = [NSMutableArray new];
	
	NSArray * results = dict[@"results"];
	
	for (NSDictionary * dict in results) {
		
		NSString * title = dict[@"title"];
		double rating = [dict[@"vote_average"] doubleValue];
		NSString * imagePath = imagePath = dict[@"poster_path"];
		NSString * overview = dict[@"overview"];
		
		[movies addObject:[[EMMovie alloc] initWithTitle:title rating:rating overview:overview imagePath:imagePath]];
	}
	return movies;
}

@end
