//
//  AppDelegate.h
//  MovieDBObjC
//
//  Created by Ethan John on 2/15/19.
//  Copyright © 2019 ya boy E. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

