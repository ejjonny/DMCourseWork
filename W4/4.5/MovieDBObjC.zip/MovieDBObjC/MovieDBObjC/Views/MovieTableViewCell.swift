//
//  MovieTableViewCell.swift
//  MovieDBObjC
//
//  Created by Ethan John on 2/15/19.
//  Copyright © 2019 ya boy E. All rights reserved.
//

import UIKit

class MovieTableViewCell: UITableViewCell {
	
	@IBOutlet weak var movieImageView: UIImageView!
	@IBOutlet weak var titleLabel: UILabel!
	@IBOutlet weak var ratingLabel: UILabel!
	@IBOutlet weak var overViewLabel: UILabel!
	
	var movie: EMMovie? {
		didSet{
			updateViews()
		}
	}
	
	func updateViews() {
		guard let movie = movie else { print("No movie passed to cell"); return }
		self.titleLabel.text = movie.title
		self.ratingLabel.text = String(movie.rating)
		self.overViewLabel.text = movie.overview
	}
}
