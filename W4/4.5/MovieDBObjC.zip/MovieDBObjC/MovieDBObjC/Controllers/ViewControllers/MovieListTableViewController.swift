//
//  MovieListTableViewController.swift
//  MovieDBObjC
//
//  Created by Ethan John on 2/15/19.
//  Copyright © 2019 ya boy E. All rights reserved.
//

import UIKit

class MovieListTableViewController: UITableViewController {
	
	// MARK: - Outlets
	@IBOutlet weak var searchBar: UISearchBar!
	
    override func viewDidLoad() {
        super.viewDidLoad()
		searchBar.delegate = self
    }

    // MARK: - Table view data source

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return EMMovieController.shared().movies.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
		guard let cell = tableView.dequeueReusableCell(withIdentifier: "movieCell", for: indexPath) as? MovieTableViewCell else { print("Unable to cast cell?"); return UITableViewCell()}
		
		// Cast movie as EMMovie object (should succeed)
		guard let movie = EMMovieController.shared().movies[indexPath.row] as? EMMovie else { print("Unable to cast as movie"); return UITableViewCell()}
		
		// Set landing pad
		cell.movie = movie
		
		// Fetch image for cell
		EMMovieController.shared().fetchImage(for: movie) { (image) in
			guard let image = image else { print("No image recieved"); return }
			DispatchQueue.main.async {
				// Update image on cell
				cell.movieImageView.image = image
			}
		}
        return cell
    }
}

extension MovieListTableViewController: UISearchBarDelegate {
	
	// MARK: - Search bar delegate
	func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
		guard let searchTerm = self.searchBar.text else { print("Search term was nil"); return }
		EMMovieController.shared().fetchMovies(forSearchTerm: searchTerm) { (success) in
			if (success) {
				DispatchQueue.main.async {
					// Reset search bar text & reload tableView on success
					self.searchBar.text = ""
					self.tableView.reloadData()
				}
			}
		}
	}
}
