//
//  EMMovieController.m
//  MovieDBObjC
//
//  Created by Ethan John on 2/15/19.
//  Copyright © 2019 ya boy E. All rights reserved.
//

#import "EMMovieController.h"

@implementation EMMovieController

static NSString * const baseUrl = @"https://api.themoviedb.org";
static NSString * const imageBaseUrl = @"https://image.tmdb.org/t/p/w500";
static NSString * const apiKey = @"006836541c703fcbc58ebf884c2dcde6";

#pragma Shared instance

+(instancetype) shared
{
	static EMMovieController * shared = nil;
	static dispatch_once_t onceToken;
	dispatch_once(&onceToken, ^{
		shared = [EMMovieController new];
	});
	return shared;
}

#pragma dataTasks
-(void)fetchMoviesForSearchTerm:(NSString *)searchTerm
				 withCompletion:(void (^)(BOOL))completion
{
	NSURL * urlWithPathComponents = [[[[NSURL URLWithString:baseUrl] URLByAppendingPathComponent:@"3"] URLByAppendingPathComponent:@"search"] URLByAppendingPathComponent:@"movie"];
	NSURLComponents * urlComponents = [NSURLComponents componentsWithURL:urlWithPathComponents resolvingAgainstBaseURL:true];
	urlComponents.queryItems = [NSArray arrayWithObjects:[NSURLQueryItem queryItemWithName:@"api_key" value:apiKey], [NSURLQueryItem queryItemWithName:@"query" value:searchTerm], nil];
	NSURL * finalUrl = [urlComponents URL];
	
	NSLog(@"Url: %@", [finalUrl absoluteString]);
	
	[[[NSURLSession sharedSession] dataTaskWithURL:finalUrl completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
		if (error) {
			NSLog(@"%@", error.localizedDescription);
			completion(false);
			return;
		}
		if (!data) {
			NSLog(@"No data recieved from API");
			completion(false);
			return;
		}
		
		NSDictionary * dict = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
		
		self.movies = [EMMovie arrayWithDict:dict];
		
		completion(true);
	}] resume];
}

-(void)fetchImageForMovie:(EMMovie *)movie
		   withCompletion:(nonnull void (^)(UIImage * _Nullable))completion
{
	NSURL * urlWithImagePath = [[NSURL URLWithString:imageBaseUrl] URLByAppendingPathComponent:[movie imagePath]];
	NSMutableURLRequest * request = [NSMutableURLRequest requestWithURL:urlWithImagePath];
	[request setHTTPMethod:@"GET"];
	
	NSLog(@"URL Request: %@", request);
	
	[[[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
		if (error) {
			NSLog(@"Image datatask recieved an error: %@", error.localizedDescription);
			completion(nil);
			return;
		}
		if (!data) {
			NSLog(@"There was no data retrieved :(");
			completion(nil);
			return;
		}
		completion([UIImage imageWithData:data]);
	}] resume];
	
}

@end
