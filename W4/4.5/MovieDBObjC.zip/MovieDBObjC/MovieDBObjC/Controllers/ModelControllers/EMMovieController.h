//
//  EMMovieController.h
//  MovieDBObjC
//
//  Created by Ethan John on 2/15/19.
//  Copyright © 2019 ya boy E. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "EMMovie.h"
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface EMMovieController : NSObject

// Singleton
+ (instancetype) shared;

// Source of truth
@property (nonatomic) NSMutableArray<EMMovie *> * movies;

-(void)fetchMoviesForSearchTerm:(NSString *)searchTerm
				 withCompletion:(void (^)(BOOL))completion;

-(void)fetchImageForMovie:(EMMovie *)movie
		   withCompletion:(void (^)( UIImage * _Nullable))completion;

@end

NS_ASSUME_NONNULL_END
