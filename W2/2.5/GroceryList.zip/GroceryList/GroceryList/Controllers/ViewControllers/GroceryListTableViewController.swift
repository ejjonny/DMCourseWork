//
//  GroceryListTableViewController.swift
//  GroceryList
//
//  Created by Ethan John on 2/1/19.
//  Copyright © 2019 ya boy E. All rights reserved.
//

import UIKit
import CoreData

class GroceryListTableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
		GroceryController.shared.fetchedResultsController.delegate = self
    }
	
	override func viewWillAppear(_ animated: Bool) {
		super.viewWillAppear(animated)
	}
	
	@IBAction func addGroceryButtonTapped(_ sender: Any) {
		let alertController = UIAlertController(title: "Whatchu need from walmart mane", message: "type it in", preferredStyle: .alert)
		alertController.addTextField(configurationHandler: nil)
		alertController.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
		alertController.addAction(UIAlertAction(title: "Done", style: .default, handler: { (_) in
			guard let fields = alertController.textFields, let input = fields[0].text else { return }
			GroceryController.shared.create(withName: input, andIsTakenCareOf: false)
		}))
		self.present(alertController, animated: true, completion: nil)
	}
	
    // MARK: - Table view data source
	
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
		
        return GroceryController.shared.fetchedResultsController.fetchedObjects?.count ?? 0
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
		guard let cell = tableView.dequeueReusableCell(withIdentifier: "groceryCell", for: indexPath) as? GroceryTableViewCell else { return UITableViewCell()}
		let grocery = GroceryController.shared.fetchedResultsController.object(at: indexPath)
		cell.updateViews(withGrocery: grocery)
		cell.delegate = self
        return cell
    }

    // MARK: - Delete functionality
	override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
			GroceryController.shared.delete(grocery: GroceryController.shared.fetchedResultsController.object(at: indexPath))
        }
    }
}

// MARK: - Button tapped functionality
extension GroceryListTableViewController: GroceryTableViewCellDelegate {
	func groceryCellButtonTapped(_ sender: GroceryTableViewCell) {
		guard let index = tableView.indexPath(for: sender) else { print("Index unwrap failed"); return }
		let grocery = GroceryController.shared.fetchedResultsController.object(at: index)
		GroceryController.shared.toggleIsTakenCareOfFor(grocery: grocery)
		sender.updateViews(withGrocery: grocery)
		tableView.reloadRows(at: [index], with: .automatic)
	}
}

// MARK: - Fetched results controller delegate
extension GroceryListTableViewController: NSFetchedResultsControllerDelegate {
	
	func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
		tableView.beginUpdates()
	}
	
	func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
		tableView.endUpdates()
	}
	
	func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
		switch type {
		case .insert:
			guard let index = newIndexPath else { return }
			tableView.insertRows(at: [index], with: .automatic)
		case .delete:
			guard let index = indexPath else { return }
			tableView.deleteRows(at: [index], with: .automatic)
		case .move:
			guard let index = indexPath,
				let newIndex = newIndexPath else { return }
			tableView.moveRow(at: index, to: newIndex)
		case .update:
			guard let index = indexPath else { return }
			tableView.reloadRows(at: [index], with: .automatic)
		}
	}
	
	func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange sectionInfo: NSFetchedResultsSectionInfo, atSectionIndex sectionIndex: Int, for type: NSFetchedResultsChangeType) {
		
		let indexSet = IndexSet(integer: sectionIndex)
		switch type {
		case .insert:
			tableView.insertSections(indexSet, with: .automatic)
		case .delete:
			tableView.deleteSections(indexSet, with: .automatic)
		default:
			return
		}
	}
}
