//
//  GroceryController.swift
//  GroceryList
//
//  Created by Ethan John on 2/1/19.
//  Copyright © 2019 ya boy E. All rights reserved.
//

import Foundation
import CoreData

class GroceryController {
	
	// Singleton
	static let shared = GroceryController()
	
	let fetchedResultsController: NSFetchedResultsController<Grocery> = {
		let request = NSFetchRequest<Grocery>(entityName: "Grocery")
		let takenCareOfSort = NSSortDescriptor(key: "takenCareOf", ascending: true)
		request.sortDescriptors = [takenCareOfSort]
		return NSFetchedResultsController(fetchRequest: request, managedObjectContext: CoreDataStack.context, sectionNameKeyPath: nil, cacheName: nil)
	}()
	
	init() {
		do {
			try fetchedResultsController.performFetch()
		} catch {
			print("Unable to load your groceries \(error): \(error.localizedDescription)")
		}
	}
	
	// CUD
	
	func create(withName name: String, andIsTakenCareOf takenCareOf: Bool) {
		Grocery(name: name, takenCareOf: takenCareOf)
		saveToPersistentStore()
	}
	
	func update(grocery: Grocery, withName name: String, andIsTakenCareOf takenCareOf: Bool) {
		grocery.name = name
		grocery.takenCareOf = takenCareOf
		saveToPersistentStore()
	}
	
	func delete(grocery: Grocery) {
		CoreDataStack.context.delete(grocery)
		saveToPersistentStore()
	}
	
	func toggleIsTakenCareOfFor(grocery: Grocery) {
		grocery.takenCareOf = !grocery.takenCareOf
		saveToPersistentStore()
	}
	
	func saveToPersistentStore() {
		do {
			try CoreDataStack.context.save()
		} catch {
			print("Unable to save your groceries \(error): \(error.localizedDescription)")
		}
	}
}
