//
//  GroceryTableViewCell.swift
//  GroceryList
//
//  Created by Ethan John on 2/1/19.
//  Copyright © 2019 ya boy E. All rights reserved.
//

import UIKit

class GroceryTableViewCell: UITableViewCell {

	@IBOutlet weak var groceryLabel: UILabel!
	@IBOutlet weak var groceryButton: UIButton!
	
	weak var delegate: GroceryTableViewCellDelegate?
	
//	override func awakeFromNib() {
//        super.awakeFromNib()
//    }
	
	@IBAction func groceryButtonTapped(_ sender: Any) {
		delegate?.groceryCellButtonTapped(self)
	}
	
	func updateViews(withGrocery grocery: Grocery) {
		self.groceryLabel.text = grocery.name
		if grocery.takenCareOf == true {
			self.groceryButton.setImage(UIImage(named: "CheckedCheckBox"), for: .normal)
		} else {
			self.groceryButton.setImage(UIImage(named: "EmptyCheckBox"), for: .normal)
		}
	}
}

protocol GroceryTableViewCellDelegate: class {
	func groceryCellButtonTapped(_ sender: GroceryTableViewCell)
}
