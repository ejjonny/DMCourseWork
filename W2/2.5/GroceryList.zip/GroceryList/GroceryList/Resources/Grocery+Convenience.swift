//
//  Grocery+Convenience.swift
//  GroceryList
//
//  Created by Ethan John on 2/1/19.
//  Copyright © 2019 ya boy E. All rights reserved.
//

import Foundation
import CoreData

extension Grocery {
	
	@discardableResult
	convenience init(name: String, takenCareOf: Bool, moc: NSManagedObjectContext = CoreDataStack.context){
		self.init(context: moc)
		self.name = name
		self.takenCareOf = takenCareOf
	}
}
