//
//  NoteTableViewController.swift
//  Notes
//
//  Created by Ethan John on 1/25/19.
//  Copyright © 2019 ya boy E. All rights reserved.
//

import UIKit

class NoteTableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableView.reloadData()
    }

    // MARK: - Table view data source

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return NoteController.shared.notes.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "noteCell", for: indexPath)
        cell.textLabel?.text = NoteController.shared.notes[indexPath.row].body
        return cell
    }

    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        switch editingStyle{
        case .delete:
            // Delete note at correct index path
            NoteController.shared.delete(note: NoteController.shared.notes[indexPath.row])
            // Delete row in tableView
            tableView.deleteRows(at: [indexPath], with: .fade)
        default:
            return
        }
    }
    // MARK: - Navigation

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toNoteDetail" {
            guard let index = tableView.indexPathForSelectedRow else { print("Unable to locate note for selected index"); return }
            guard let destinationVC = segue.destination as? NoteDetailViewController else { print("Unable to cast destinationVC as correct type"); return }
            destinationVC.note = NoteController.shared.notes[index.row]
        } else {
            return
        }
    }
}
