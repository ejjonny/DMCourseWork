import UIKit

class Person {
    var name: String
    var favoriteColor: String?
    var favoriteMovie: String?
    
    init(_ name: String) {
        self.name = name
    }
}

let ethan = Person("Ethan")

ethan.favoriteMovie = "Light Blue"

if ethan.favoriteColor != nil || ethan.favoriteMovie != nil {
    if let favoriteColor = ethan.favoriteColor, let favoriteMovie = ethan.favoriteMovie {
        print("\(ethan.name)'s favorite color is \(favoriteColor), and his favorite movie is \(favoriteMovie).")
    } else if let favoriteColor = ethan.favoriteColor, ethan.favoriteMovie == nil {
        print("\(ethan.name)'s favorite color is \(favoriteColor).")
    } else if let favoriteMovie = ethan.favoriteMovie, ethan.favoriteColor == nil {
        print("\(ethan.name)'s favorite movie is \(favoriteMovie).")
    }
} else if ethan.favoriteMovie == nil, ethan.favoriteColor == nil {
    print("\(ethan.name) doesn't like anything and hates the world")
}
