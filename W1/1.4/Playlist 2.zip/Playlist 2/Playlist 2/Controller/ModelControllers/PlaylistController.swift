//
//  PlaylistController.swift
//  Playlist 2
//
//  Created by Ethan John on 1/23/19.
//  Copyright © 2019 ya boy E. All rights reserved.
//

import Foundation

class PlaylistController {
    
    // MARK: - Shared Instances / Singleton
    static let shared = PlaylistController()
    
    // MARK: - Source of Truth
    var playlists: [Playlist] = []
    
    func createPlaylist(withName name: String) {
        let playlist = Playlist(name: name)
        playlists.append(playlist)
    }
    
    func delete(playlist: Playlist) {
        guard let index = playlists.index(of: playlist) else { return }
        playlists.remove(at: index)
    }
    
    func add(song: Song, toPlaylist playlist: Playlist) {
        playlist.songs.append(song)
    }
    
    func remove(song: Song, fromPlaylist playlist: Playlist) {
        guard let index = playlist.songs.index(of: song) else { return }
        playlist.songs.remove(at: index)
    }
}
