//
//  Contact.swift
//  ContactsCK
//
//  Created by Ethan John on 3/1/19.
//  Copyright © 2019 ya boy E. All rights reserved.
//

import Foundation
import CloudKit

struct Keys {
	
	// Mark: - Constants
	static let contactType = "contact"
	static let nameKey = "name"
	static let numberKey = "number"
	static let emailKey = "email"
	static let idKey = "ID"
}

class Contact {
	
	// Mark: - Properties
	var name: String
	var number: String
	var email: String
	var recordID: CKRecord.ID
	
	// Mark: - Initializers
	// Base init
	init(name: String, number: String, email: String, recordID: CKRecord.ID = CKRecord.ID(recordName: UUID().uuidString)) {
		self.name = name
		self.number = number
		self.email = email
		self.recordID = recordID
	}
	
	// Record to Contact object
	convenience init?(record: CKRecord) {
		guard let name = record[Keys.nameKey] as? String,
			let number = record[Keys.numberKey] as? String,
			let email = record[Keys.emailKey] as? String else { return nil }
		self.init(name: name, number: number, email: email, recordID: record.recordID)
	}
}

extension CKRecord {
	
	// Contact object to record
	convenience init(contact: Contact) {
		
		self.init(recordType: Keys.contactType, recordID: contact.recordID)
		self.setValue(contact.name, forKey: Keys.nameKey)
		self.setValue(contact.email, forKey: Keys.emailKey)
		self.setValue(contact.number, forKey: Keys.numberKey)
	}
}
