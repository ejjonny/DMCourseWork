//
//  ContactController.swift
//  ContactsCK
//
//  Created by Ethan John on 3/1/19.
//  Copyright © 2019 ya boy E. All rights reserved.
//

import Foundation
import CloudKit

class ContactController {
	
	// Mark: - Singleton
	static let shared = ContactController()
	
	// Mark: - Sources of Truth
	var contacts: [Contact] = []
	
	let privateDB = CKContainer.default().privateCloudDatabase
	
	// Mark: - Data / CloudKit control
	func save(contact: Contact, completion: @escaping (Bool) -> Void) {
		
		let record = CKRecord(contact: contact)
		privateDB.save(record) { (record, error) in
			if let error = error {
				print("Error saving contact: \(error, error.localizedDescription)")
				completion(false)
				return
			}
			guard let record = record,
				let contact = Contact(record: record) else { print("There was an issue saving the contact") ; completion(false) ; return }
			self.contacts.append(contact)
			NotificationCenter.default.post(name: Notification.Name("ContactsChanged"), object: nil)
			completion(true)
		}
	}
	
	func update(contact: Contact, with name: String, number: String, email: String, completion: @escaping (Bool) -> Void) {
		
		contact.name = name
		contact.number = number
		contact.email = email
		
		let op = CKModifyRecordsOperation(recordsToSave: [CKRecord(contact: contact)], recordIDsToDelete: nil)
		op.savePolicy = .changedKeys
		op.queuePriority = .high
		op.qualityOfService = .userInteractive
		op.completionBlock = { () in
			NotificationCenter.default.post(name: Notification.Name("ContactsChanged"), object: nil)
		}
		
		privateDB.add(op)
		completion(true)
	}
	
	func fetch(completion: @escaping (Bool) -> Void) {
		
		let predicate = NSPredicate(value: true)
		let query = CKQuery(recordType: Keys.contactType, predicate: predicate)
		privateDB.perform(query, inZoneWith: nil) { (records, error) in
			if let error = error {
				print("Error fetching contacts: \(error, error.localizedDescription)")
				completion(false)
				return
			}
			guard let records = records else { print("No records recieved back from cloud") ; completion(false) ; return }
			self.contacts = records.compactMap{Contact(record: $0)}
			completion(true)
		}
	}
}
