//
//  DetailViewController.swift
//  ContactsCK
//
//  Created by Ethan John on 3/1/19.
//  Copyright © 2019 ya boy E. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

	// Mark: - Outlets
	@IBOutlet weak var nameField: UITextField!
	@IBOutlet weak var numberField: UITextField!
	@IBOutlet weak var emailField: UITextField!
	
	// Mark: - Properties
	var contact: Contact?
	
	// Mark: - Lifecycle
	override func viewDidLoad() {
        super.viewDidLoad()
		updateViews()
    }
	
	// Mark: - Actions
	@IBAction func saveButtonTapped(_ sender: Any) {
		
		guard let name = nameField.text, !name.isEmpty,
			let number = numberField.text, !number.isEmpty,
			let email = emailField.text, !number.isEmpty else { return }
		
		if let contact = self.contact {
			ContactController.shared.update(contact: contact, with: name, number: number, email: email) { (success) in
				print(success ? "Successfully updated contact" : "Unable to update contact")
			}
		} else if self.contact == nil {
			let contact = Contact(name: name, number: number, email: email)
			ContactController.shared.save(contact: contact) { (success) in
				print(success ? "Successfully saved contact" : "Unable to save contact")
			}
		}
		self.navigationController?.popViewController(animated: true)
	}
	
	// Mark: - View Control
	func updateViews() {
		guard let contact = contact else { return }
		nameField.text = contact.name
		numberField.text = contact.number
		emailField.text = contact.email
	}
}
