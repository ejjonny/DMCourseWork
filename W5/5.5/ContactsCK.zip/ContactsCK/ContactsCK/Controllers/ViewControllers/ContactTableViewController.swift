//
//  ContactTableViewController.swift
//  ContactsCK
//
//  Created by Ethan John on 3/1/19.
//  Copyright © 2019 ya boy E. All rights reserved.
//

import UIKit

class ContactTableViewController: UITableViewController {

	// Mark: - Life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
		sync()
		NotificationCenter.default.addObserver(self, selector: #selector(self.updateContacts), name: Notification.Name("ContactsChanged"), object: nil)
    }
	
    // MARK: - Table view data source
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ContactController.shared.contacts.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "contactCell", for: indexPath)
		cell.textLabel?.text = ContactController.shared.contacts[indexPath.row].name
        return cell
    }
	
	// Mark: - TableView / data control
	func sync() {
		ContactController.shared.fetch { (success) in
			print(success ? "Successfully fetched user contacts" : "Unable to fetch user contacts")
			DispatchQueue.main.async {
				self.tableView.reloadData()
			}
		}
	}
	
	@objc func updateContacts() {
		DispatchQueue.main.async {
			self.tableView.reloadData()
		}
	}

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */
	
    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
		if segue.identifier == "toContact" {
			guard let index = tableView.indexPathForSelectedRow else { return }
			guard let destination = segue.destination as? DetailViewController else { return }
			destination.contact = ContactController.shared.contacts[index.row]
		}
    }
}
