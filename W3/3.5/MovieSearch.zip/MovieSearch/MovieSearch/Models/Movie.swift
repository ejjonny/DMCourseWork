//
//  Movie.swift
//  MovieSearch
//
//  Created by Ethan John on 2/8/19.
//  Copyright © 2019 ya boy E. All rights reserved.
//

import Foundation


struct TopLevelData: Codable {
	let page: Int
	let total_results: Int
	let total_pages: Int
	let results: [Movie]
}

struct Movie: Codable {
	
	let title: String
	var overview: String
	var rating: Double
	var imagePath: String?
	
	private enum CodingKeys: String, CodingKey {
		case title
		case overview
		case rating = "vote_average"
		case imagePath = "poster_path"
	}
}
