//
//  MovieTableViewCell.swift
//  MovieSearch
//
//  Created by Ethan John on 2/8/19.
//  Copyright © 2019 ya boy E. All rights reserved.
//

import UIKit

class MovieTableViewCell: UITableViewCell {

	// MARK: - Landing pad
	var movie: Movie? {
		didSet {
			self.updateViews()
		}
	}
	
	// MARK: - Outlets
	@IBOutlet weak var posterImageView: UIImageView!
	@IBOutlet weak var nameLabel: UILabel!
	@IBOutlet weak var ratingLabel: UILabel!
	@IBOutlet weak var descriptionLabel: UILabel!
	
	func updateViews() {
		guard let movie = movie else { return }
		self.nameLabel.text = movie.title
		self.ratingLabel.text = "Movie rating: \(String(movie.rating))"
		self.descriptionLabel.text = movie.overview
	}
}
