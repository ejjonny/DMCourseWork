//
//  MainTableViewController.swift
//  MovieSearch
//
//  Created by Ethan John on 2/8/19.
//  Copyright © 2019 ya boy E. All rights reserved.
//

import UIKit

class MainTableViewController: UITableViewController {

	// MARK: - Outlets
	@IBOutlet weak var searchBar: UISearchBar!
	
	var movies: [Movie] = []
	
    override func viewDidLoad() {
        super.viewDidLoad()
		searchBar.delegate = self
    }

    // MARK: - Table view data source
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
		print(movies.count)
        return movies.count
    }
	
	// Consistent cell height
	override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
		return 250
	}

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
		guard let cell = tableView.dequeueReusableCell(withIdentifier: "movieCell", for: indexPath) as? MovieTableViewCell else { print("Unable to cast cell"); return UITableViewCell()}
		
		cell.movie = movies[indexPath.row]
		
		// Start fetch for the image associated with the cell.
		MovieController.fetchMovieImages(forMovie: movies[indexPath.row]) { (image) in
			guard let image = image else { return }
			DispatchQueue.main.async {
				// Reloading the data here doesn't work so I think the app relies on the image data being back by the time the movie fetch is finished to be able to actually populate the cell. What is the best way to do this?
				cell.posterImageView.image = image
			}
		}
        return cell
    }
}

// MARK: - Search bar delegate
extension MainTableViewController: UISearchBarDelegate {
	func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
		guard let input = searchBar.text, !input.isEmpty else { print("Text in search bar was nil?"); return }
		MovieController.fetchMovies(withQuery: input) { (movies) in
			self.movies = movies
			DispatchQueue.main.async {
				self.tableView.reloadData()
				searchBar.text = ""
			}
		}
	}
}
