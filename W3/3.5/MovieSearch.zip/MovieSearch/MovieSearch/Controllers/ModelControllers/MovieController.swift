//
//  MovieController.swift
//  MovieSearch
//
//  Created by Ethan John on 2/8/19.
//  Copyright © 2019 ya boy E. All rights reserved.
//

import UIKit

class MovieController {
	
	static let baseURL = URL(string: "https://api.themoviedb.org/3")
	static let imageBaseURL = URL(string: "https://image.tmdb.org/t/p/w500")
	
	private static let apiKey = "006836541c703fcbc58ebf884c2dcde6"
	
	// MARK: - Movie fetch
	static func fetchMovies(withQuery query: String, completion: @escaping ([Movie]) -> Void) {
		
		guard let url = baseURL?.appendingPathComponent("search").appendingPathComponent("movie") else { print("Issue with URL"); completion([]); return }
		
		var components = URLComponents(url: url, resolvingAgainstBaseURL: true)

		components?.queryItems = [ URLQueryItem(name: "api_key", value: apiKey), URLQueryItem(name: "query", value: query)]

		guard let finalUrl = components?.url else { print("Issue with URL"); completion([]); return }
		
		print(finalUrl)
		
		URLSession.shared.dataTask(with: finalUrl) { (data, response, error) in
			if let error = error { print("Datatask recieved an error", error, error.localizedDescription); completion([]); return }
			guard let data = data else { print("No data recieved"); completion([]); return }
			if let response = response { print("Page response: \(response)") }
			do {
				let result = try JSONDecoder().decode(TopLevelData.self, from: data)
				completion(result.results)
			} catch {
				print("Couldn't decode", error, error.localizedDescription)
				completion([])
			}
		}.resume()
	}
	
	// MARK: - Image fetch
	static func fetchMovieImages(forMovie movie: Movie, completion: @escaping (UIImage?) -> Void) {
		
		guard let imagePath = movie.imagePath, let url = imageBaseURL?.appendingPathComponent(imagePath) else { print("No image path on this movie / failed to append path extension"); completion(nil); return }
		print(url)
		
		URLSession.shared.dataTask(with: url) { (data, response, error) in
			if let error = error { print("Couldn't get this image", error, error.localizedDescription); completion(nil); return }
			guard let data = data else { print("No data returned"); completion(nil); return }
			completion(UIImage(data: data))
		}.resume()
		
	}
}
